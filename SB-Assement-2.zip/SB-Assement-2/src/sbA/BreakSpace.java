package sbA;
import java.util.*;
public class BreakSpace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StringTokenizer str1=new StringTokenizer("This Is Java Programming."," ");
		while (str1.hasMoreTokens())
		{
			System.out.println(str1.nextToken());
			
		}
		
		
		}

}
