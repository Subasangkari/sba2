package com.myPhoneNumber.Task;

public class Norway extends Country {
@Override
public boolean PhoneNumberFormat(String str) {
		int count=0;
		String str1= "True";
		String s1="valid";
		String s2="invalid";
		char[] arr = str.toCharArray();
		for(int i =0; i<str.length(); i++) {
			if(i <= 6) {
			if (i==0 && arr[i] == '+') {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==1 && arr[i] == 52) {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			
			if (i==2 && arr[i] == 55) {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==3 && arr[i] == '-') {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==4 && arr[i] == 52) {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==5 && arr[i] == 57) {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==6 && arr[i] == '-') {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			}
			if(i >= 7 && i<=8) {
			if(arr[i] >= 48 && arr[i] <= 57) {
				count++;
				str1=s1;
				}
			else {
				str1 = s2;
				}
		}
			if (i==9 && arr[i] == '-') {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if(i >= 10 && i<=11) {
				if(arr[i] >= 48 && arr[i] <= 57) {
					count++;
					str1=s1;
					}
				else {
					str1 = s2;
					}
			}
			if (i==12 && arr[i] == '-') {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}

			
			
			if(i >= 13 && i<=14) {
				if(arr[i] >= 48 && arr[i] <= 57) {
					count++;
					str1=s1;
					}
				else {
					str1 = s2;
					}
			}
			
		}
		if(count == 15 && str1==s1) {
			return true;
			}
		else {
			return false;
		}
}


}
