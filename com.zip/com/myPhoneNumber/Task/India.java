package com.myPhoneNumber.Task;
public class India extends Country{
	boolean PhoneNumberFormat(String str) {
			int count=0;
			String str1= "True";
			String s1="valid";
			String s2="invalid";
			char[] arr = str.toCharArray();
			for(int i =0; i<str.length(); i++) {
				if(i <= 3) {
				if (i==0 && arr[i] == '+') {
					str1=s1;
					count++;
				}
				else {
					str1=s2;
				}
				if (i==1 && arr[i] == 57) {
					str1=s1;
					count++;
				}
				else {
					str1=s2;
				}
				
				if (i==2 && arr[i] == 49) {
					str1=s1;
					count++;
				}
				else {
					str1=s2;
				}
				if (i==3 && arr[i] == '-') {
					str1=s1;
					count++;
				}
				else {
					str1=s2;
				}
				}
				if(i >= 4) {
				if(arr[i] >= 48 && arr[i] <= 57) {
					count++;
					str1=s1;
					}
				else {
					str1 = s2;
					}
			}
			}
			if(count == 14 && str1==s1) {
				return true;
				}
			else {
				return false;
			}
	}
}
	

