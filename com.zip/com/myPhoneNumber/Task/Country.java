package com.myPhoneNumber.Task;
interface PhoneNumber{
	boolean PhoneNumberFormat(String str);
}

abstract class Country implements PhoneNumber {

}




