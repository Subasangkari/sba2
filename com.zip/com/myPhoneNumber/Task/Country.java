package com.myPhoneNumber.Task;

interface PhoneNumber{
	boolean PhoneNumberFormat(String str);
}

public abstract class Country {

}




