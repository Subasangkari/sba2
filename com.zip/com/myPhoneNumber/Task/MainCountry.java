package com.myPhoneNumber.Task;

public class MainCountry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     India i = new India();
     System.out.println(i.PhoneNumberFormat("+91-9840830207"));
     
     brazil b = new brazil();
     System.out.println(b.PhoneNumberFormat("+55 15 55555-4444"));
     
     Norway n = new Norway();
     System.out.println(n.PhoneNumberFormat("+47-49-67-54-87"));
	
     Quatar q = new Quatar();
     System.out.println(q.PhoneNumberFormat("+974 3399-9999"));
	
     Trukey t = new Trukey();
     System.out.println(t.PhoneNumberFormat("+90 509-999999"));
	
     Trukey t1 = new Trukey();
     System.out.println(t1.PhoneNumberFormat("0509-999-999"));
	
	}

}
