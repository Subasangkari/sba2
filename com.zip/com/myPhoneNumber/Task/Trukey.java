package com.myPhoneNumber.Task;

public class Trukey extends Country{
@Override
public boolean PhoneNumberFormat(String str) {
		int count=0;
		String str1= "True";
		String s1="valid";
		String s2="invalid";
		char[] arr = str.toCharArray();
		for(int i =0; i<str.length(); i++) {
			if (i==0 && arr[i] == '+'){
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==1 && arr[i] == 57)  {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			
			if (i==2 && arr[i] == 48) {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if (i==3 && arr[i] == ' ') {
				str1=s1;
				count++;
			}
			else {
				str1=s2;
			}
			if(i==4 && arr[i] == 53) {
				str1=s1;
				count++;
				}
			else {
				str1 = s2;
				}
			if(i==5 && arr[i] == 48) {
				str1=s1;
				count++;
				}
			else {
				str1 = s2;
				}
			if(i==6 && arr[i] == 57) {
				str1=s1;
				count++;
				}
			else {
				str1 = s2;
				}
			if(i==7 && arr[i] == '-') {
				str1=s1;
				count++;
				}
			else {
				str1 = s2;
				}
			if(i >= 8) {
				if(arr[i] >= 48 && arr[i] <= 57) {
					count++;
					str1=s1;
					}
				else {
					str1 = s2;
					}
			}
		}
		
if(count == 14 && str1==s1) {
			str1=s1;
			}
		else {
			str1=s2;
		}
if(str1==s2) {
	count=0;
	for(int i =0; i<str.length(); i++) {

		if (i==0 && arr[i] == 48){
			str1=s1;
			count++;
		}
		else {
			str1=s2;
		}
		if (i==1 && arr[i] == 53)  {
			str1=s1;
			count++;
		}
		else {
			str1=s2;
		}
		
		if (i==2 && arr[i] == 48) {
			str1=s1;
			count++;
		}
		else {
			str1=s2;
		}
		if (i==3 && arr[i] == 57) {
			str1=s1;
			count++;
		}
		else {
			str1=s2;
		}
		if(i==4 && arr[i] == '-') {
			str1=s1;
			count++;
			}
		else {
			str1 = s2;
			}
		if(i >= 5 && i<=7) {
			if(arr[i] >= 48 && arr[i] <= 57) {
				count++;
				str1=s1;
				}
			else {
				str1 = s2;
				}
		}
		if(i==8 && arr[i] =='-') {
			str1=s1;
			count++;
			}
		else {
			str1 = s2;
			}
		if(i >= 9 && i<=11) {
			if(arr[i] >= 48 && arr[i] <= 57) {
				count++;
				str1=s1;
				}
			else {
				str1 = s2;
				}
		}
	}
	if(count==12 && str1==s1) {
		str1=s1;
	}
	else {
		str1=s2;
	}
}
	
	if(str1==s1)
		return true;
	else
		return false;

	}
}
	