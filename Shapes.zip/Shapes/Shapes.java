package Shapes;
public class Shapes {
    circle circle;
	triangle triangle;
public Shapes(circle circle,triangle triangle) {
		super();
		this.circle=circle;
		this.triangle=triangle;
	}
public circle getcircle() {
	return circle;
	}
public void setcircle(circle circle) {
	this.circle = circle;
}
public triangle gettriangle() {
	return triangle;
}
public void settrianle(triangle triangle) {
	this.triangle=triangle;
}
}