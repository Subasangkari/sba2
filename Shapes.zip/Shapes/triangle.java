package Shapes;
public class triangle {
	int base;
	int height;
	int side;
	String typeOfTriangle;
	
	public int getbase() {
		return base;
	}
	
	public void setradius(int base) {
		this.base = base;
	}

	public int getheight() {
		return height;
	}
	
	public void setheight(int height) {
		this.height = height;
	}
	
	public int getside() {
		return side;
	}
	
	public void setside(int side) {
		this.side = side;
	}
	
	public String gettypeOfTriangle() {
		return typeOfTriangle;
	}
	
	public void setgettypeOfTriangle(String typeOfTriangle) {
		this.typeOfTriangle = typeOfTriangle;
	}
	
	public triangle(int base,int height,int side,String typeOfTriangle) {
	super();
	this.base=base;
	this.height=height;
	this.side=side;
	this.typeOfTriangle=typeOfTriangle;
	}
	
	@Override
	public String toString() {
		return "base= " +getbase()+ "; " +"heigth= "+getheight()+"; "+"side= "+getside()+"; "+"typeOfTriangle= "+gettypeOfTriangle();
	}
}