package Shapes;
public class circle {
	int radius;
	int diameter;
	
	public int getradius() {
		return radius;
	}
	
	public void setradius(int radius) {
		this.radius = radius;
	}

	public int getdiameter() {
		return diameter;
	}
	
	public void setdiameter(int diameter) {
		this.diameter = diameter;
	}
	
	public circle(int radius,int diameter) {
	super();
	this.radius=radius;
	this.diameter=diameter;
	}
	
	@Override
	public String toString() {
		return "radius =" +getradius()+ "; " +"diameter= "+getdiameter();
	}
}