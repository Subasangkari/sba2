package Shapes;

public class DrawShape {

	public static void main(String[] args) {
		circle circle=new circle(5,10);
		triangle triangle=new triangle(5,10,3,"Rigth-Angled Triangle");
        Shapes Shapes=new Shapes(circle,triangle);
        System.out.println(Shapes.getcircle());
        System.out.println(Shapes.gettriangle());
	}

}
